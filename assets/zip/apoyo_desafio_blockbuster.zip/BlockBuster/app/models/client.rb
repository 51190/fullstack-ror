class Client < ApplicationRecord
  has_many :movies
end
